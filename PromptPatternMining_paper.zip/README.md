# Prompt Pattern Mining in Vibe Coding

A graduate seminar research project, Spring 2026, Texas A&M University-San Antonio.
Authors: Teja Reddy Mandadi, Visesh Bentula, Umapathi Konduri.

This README is a long-form companion to the IEEE conference paper. It is
written for a reader who has never seen this project before. It explains
what the work is, why it exists, what the dataset is, how the analysis
works, what every result means, and what every piece of jargon (p-value,
odds ratio, Cohen's kappa, AUC, etc.) refers to. Read this first if you
want a teaching-level overview before you open the paper PDF.

---

## 1. What is this project about?

When you talk to ChatGPT (or any large language model, "LLM"), the way you
phrase your request changes the quality of the answer. Anyone who has used
these tools has felt this. A vague prompt produces a vague answer. A prompt
that says "return the answer as a JSON object with keys X and Y" produces a
structured answer. Adding "you are an expert in Python" sometimes helps and
sometimes does not.

The software industry has noticed. There is now a working idea called
"prompt engineering": the craft of writing the inputs that go into an LLM so
that the outputs are useful. Most of what is written about prompt
engineering is anecdotal. People share tips on Twitter or in blog posts.
There are some controlled lab studies, but those use prompts written by the
researchers, not by working developers.

We wanted to know what actually works in real developer workflows. Not lab
prompts. Real ones. So we took 6,413 conversations between developers and
ChatGPT, taken from public GitHub pull requests, issues, code files,
discussions, and Hacker News threads, and we asked: which structural
features of the prompt actually predict whether the conversation ended in a
useful piece of code?

We call this style of work "vibe coding": the developer writes natural
language, the LLM writes code, and they iterate until it works. The
developer controls one thing in this loop, and that is the prompt. So the
prompt is the right place to look for actionable advice.

### Does the project name match the project?

Yes. "Prompt Pattern Mining" = we mine (statistically extract) prompt
patterns. "Vibe Coding" = the multi-turn natural-language style developers
use to coax code out of LLMs. The full title therefore says exactly what
the paper does: it audits structural prompt patterns inside real vibe
coding conversations.

---

## 2. Why does this matter?

Three reasons.

First, every developer who uses an LLM makes prompt design decisions
several times an hour. Replacing anecdote with statistics makes those
decisions faster and better.

Second, the gap between lab benchmarks and real conversations is real. Lab
studies tend to use clean, well-formed prompts. Real conversations are
messy: they have follow-up questions, mid-stream corrections, off-topic
sidebars, and varying clarity. Effects measured in the lab may or may not
survive in the wild.

Third, results that hold across different LLMs (not just ChatGPT) are more
useful as engineering guidance. So we replicated our key finding on three
top-tier LLMs from three different vendors: Kimi K2 (Moonshot AI), Claude
Sonnet 4.6 (Anthropic), and Gemini 3.1 Pro Preview (Google).

---

## 3. The dataset: DevGPT

We use the public DevGPT v10 release by Xiao et al. (arXiv:2309.03914).
DevGPT is a corpus of developer-ChatGPT conversations that developers
voluntarily shared on GitHub and other public platforms.

After cleaning (parsing JSON, dropping corrupted threads, removing
duplicates, normalizing whitespace, separating user prompts from model
answers), we retain:

- 6,413 conversations
- 54,449 turns total. A "turn" is one user message plus one model reply.
- 10 dataset snapshots between August 2023 and May 2024
- 6 source types: pull requests, issues, commits, discussions, code files,
  Hacker News threads
- 19 programming languages with at least 25 conversations each. Top three
  by conversation count: CSS (1,313), Python (703), TypeScript (652).
- 8 ChatGPT model variants: GPT-3.5, GPT-4, Default, Plugins, Advanced
  Data Analysis, GPT-4-GIZMO, OTHER, etc.

3,529 of the 6,413 conversations are labeled success (55.0%). The label
itself is described in Section 4.

---

## 4. The success label: how do we decide a conversation "worked"?

The biggest methodological problem is that we cannot run the generated
code at scale to check whether it works. So we use textual signals.

A conversation is labeled SUCCESS when both of these hold:

1. The assistant produced code in at least one turn (the answer contained
   a fenced code block).
2. The developer never expressed strong negative feedback in any later
   turn. "Strong negative feedback" is a regex match on phrases like
   "not working", "doesn't work", "still broken", "error persists",
   "failed", "wrong", "didn't fix".

Otherwise the conversation is FAILURE.

This rule labels 3,529 conversations as success and 2,884 as failure. The
base success rate is 55.03%. We later validated this label by manually
re-labeling 50 random conversations against the protocol document. The
manual label and the auto label agreed 92.0% of the time, with Cohen's
kappa of 0.834 (see Section 7 for what kappa is and why this number is
strong).

---

## 5. The features we extract from each conversation

We extract eleven features per conversation. Six describe how the first
prompt is written (structural). Five describe how the developer interacts
across multiple turns (behavioral).

### Structural features (from the first user prompt)

1. **Prompt length** -- number of tokens in the first user message.
2. **Constraint count** -- regex matches for words like "must", "should",
   "do not", "only", "exactly". A prompt that says "you must use a loop
   and do not use recursion" has constraint count = 2.
3. **Example count** -- regex matches for "for example", "input:",
   "output:", and fenced code blocks inside the prompt. Captures whether
   the user gave a worked example.
4. **Specification clarity count** -- regex matches for "the function
   should", "given a", "returns a", "implement a", "create a function".
   Captures whether the user said precisely what they want.
5. **Role instruction (binary)** -- 1 if the prompt contains "you are X",
   "act as", or "as a". 0 otherwise. The classic "you are a senior Python
   engineer" pattern.
6. **Output format (binary)** -- 1 if the prompt contains "json",
   "markdown", "table", "return only", "respond with". 0 otherwise.
   Captures whether the user told the model how to format the answer.

### Behavioral features (across the whole conversation)

7. **Iteration count** -- total number of turns in the conversation.
8. **Refinement turns** -- count of turns containing "fix", "bug",
   "error", "not working", "retry", "improve". The user clarifying or
   pushing back.
9. **Correction cycles** -- count of turn pairs where the user explicitly
   corrects a wrong answer.
10. **Prompt token growth** -- length of the last user prompt minus
    length of the first user prompt. Did the user have to re-explain at
    length?
11. **First specification clarity binary** -- 1 if any clarity phrase
    matched in the first turn.

The full regex catalog is in `config/feature_patterns.yaml` of the
project repository.

### Why these features and not others?

Each feature has either prior empirical support (Wu et al. 2024 mine 13
prompt patterns, six of which overlap with our list) or a clear
hypothesis tied to one of our research questions (output format,
constraints, examples for RQ1; refinement and iteration for RQ2). We
deliberately did not include semantic features (topic embeddings, code
correctness scores) so the model stays interpretable and reproducible.

---

## 6. The statistical model

We fit a logistic regression. This is a standard model for predicting a
binary outcome (success or failure) from a set of input features. For
each feature, the model learns a coefficient that tells us how much the
feature shifts the probability of success.

Specifics:

- **Algorithm**: logistic regression with L2 regularization at C = 1.0.
  L2 regularization penalizes large coefficients to reduce overfitting.
  C = 1.0 is the scikit-learn default and is a good middle ground.
- **Class weight**: "balanced". The dataset has slightly more success
  (55%) than failure (45%); class weight "balanced" tells the model to
  weight the two classes equally during training so it does not just
  predict "success" for everything.
- **Controls**: alongside the eleven features of interest, we include
  four sets of one-hot dummy variables to control for confounders
  (variables that could create a fake association). These are: repository
  language (12 dummies), source type (5 dummies), snapshot date (9
  dummies), and ChatGPT model variant (8 dummies). Total controls: 34
  variables.
- **Validation**: 5-fold stratified cross validation. The data is split
  into 5 groups of equal size with the same success/failure ratio in
  each group. For each fold we train on 4 groups and test on the
  held-out 5th group. We average test performance across the 5 folds.
  This protects against overfitting to a particular split.
- **Software**: scikit-learn 1.4 for fitting, statsmodels 0.14 for
  confidence intervals and p-values. Random seed 42.

Why logistic regression and not a neural net? Because the goal is
interpretation: each odds ratio reads as actionable advice. A neural net
would give us higher AUC at the cost of opacity. We checked: a 2,000
feature bag-of-words logistic on the raw first prompt (a much larger
feature space) reaches AUC 0.782 (see Section 8.2). Our 11-feature model
reaches 0.799. The extra structure costs us almost nothing in raw fit and
buys us interpretability.

---

## 7. Glossary of statistical terms used in the paper

This is the section a reader without a stats background should keep open
while reading the paper.

### ROC-AUC (Receiver Operating Characteristic - Area Under Curve)

A number between 0.5 and 1.0 that measures how well a model can
distinguish two classes. 0.5 is random guessing. 1.0 is perfect.
Rough labels: 0.7 OK, 0.8 good, 0.9 very good. Our model gets 0.799,
which sits right at the "good" threshold.

AUC is invariant to class imbalance, which is why we report it as the
main performance number. It also has a clean interpretation: if you take
one random success conversation and one random failure conversation, the
AUC is the probability the model gives a higher success score to the
success one.

### Accuracy

Fraction of predictions that are correct. Easy to read but misleading
when classes are imbalanced. Our accuracy is 0.726 (72.6% of
conversations classified correctly).

### F1 score

Harmonic mean of precision (of the conversations the model called
success, how many really were?) and recall (of the conversations that
really were success, how many did the model catch?). Range 0 to 1, higher
is better. Our F1 is 0.755.

### Odds and Odds Ratio (OR)

**Odds** = probability of success divided by probability of failure. If
the chance of success is 75%, the odds are 0.75 / 0.25 = 3 to 1.

**Odds ratio** is the multiplicative change in odds when a feature changes
by one unit. For a binary feature like "output format present", OR = 1.75
means the odds of success are 1.75 times higher when an output format
instruction is present. For a continuous feature like "refinement turns",
OR = 1.19 means each additional refinement turn multiplies the odds by
1.19, so two extra turns multiply odds by 1.19 squared = 1.42, three
turns by 1.69, and so on.

OR > 1 = the feature helps. OR = 1 = no effect. OR < 1 = the feature
hurts. OR = 0.65 means the odds are 35% lower when the feature is
present.

### 95% Confidence Interval (CI)

A range that tells us how precise an estimate is. A 95% CI of [1.40,
2.19] on an odds ratio means: if we repeated the study many times under
the same conditions, 95% of the resulting CIs would contain the true
population odds ratio. Wide intervals = uncertain. Narrow intervals =
precise.

A CI that does not include 1.0 means the effect is statistically distinct
from "no effect".

### p-value

A probability between 0 and 1 that measures how surprising the data would
be if the feature had no real effect. Smaller is more surprising.

The standard threshold is 0.05. If p < 0.05, we say the result is
"statistically significant". If p < 0.001, the result is very strong.
Our output format effect has p < 1e-6, which means we would expect to
see this finding by chance fewer than once in a million repeats if
there were no real effect.

p-values do NOT measure how big or important the effect is. They only
measure how unlikely the data is under the null hypothesis. We always
report effect sizes (OR, Cohen's d) alongside p-values for that reason.

### Cohen's kappa

A number between -1 and 1 that measures agreement between two raters,
correcting for the chance level of agreement. Useful when both raters
might agree by accident even if they didn't really know what they were
doing.

The Landis and Koch scale (1977):

- kappa < 0.2 = poor agreement
- 0.2 to 0.4 = fair
- 0.4 to 0.6 = moderate
- 0.6 to 0.8 = substantial
- 0.8 to 1.0 = almost perfect

Our manual validation kappa is 0.834, which is "almost perfect".

### Cohen's d

A measure of effect size for comparing two means. Roughly, d = the
difference of means divided by the pooled standard deviation. Cohen's
labels:

- d = 0.2 = small
- d = 0.5 = medium
- d = 0.8 = large

Our cross-vendor d ranges from 0.59 (Claude) to 0.80 (Gemini), which is
a moderate to large effect.

### Greek letters used in the paper

- **alpha (α)** -- the significance threshold. We use alpha = 0.05.
- **kappa (κ)** -- Cohen's kappa, defined above.
- **Δ (delta)** -- a difference. Δ AUC = AUC drop after dropping a
  feature group. Δ success = percentage point change in success rate.
- **rho (ρ)** -- Spearman's rank correlation coefficient. Used in the
  correlation heatmap.
- **ℓ₂ (ell-two)** -- shorthand for the L2 norm. "L2 regularization"
  penalizes the squared sum of model coefficients during fitting.

### "Pre-registered"

In the interactions analysis we say the four interaction terms were
"pre-registered". This means we wrote down which interactions we would
test BEFORE we looked at the data. This protects against the temptation
to test many interactions and only report the ones that came out
significant (a problem called "p-hacking" or "fishing"). Pre-registration
is best practice in modern empirical research.

### "Two-way interaction"

In a regression, an interaction term captures how the effect of one
feature depends on another. A two-way interaction is the product of two
features. For example, our `Role × Output Format` interaction is just the
binary role flag multiplied by the binary output format flag. The
coefficient on this term tells us how much extra (or less) the joint
effect is, beyond the sum of the two main effects.

### "Stratified" cross validation

Stratified means each fold preserves the original class ratio. Our
55%/45% split shows up in every fold rather than concentrating successes
in one fold by accident.

---

## 8. The headline results

The paper reports nine analyses. This section narrates each one in plain
language with the actual numbers.

### 8.1 Headline performance

The fitted model reaches:

- ROC-AUC: 0.799 (SD 0.009 across 5 folds)
- Accuracy: 0.726
- F1: 0.755

The 11 prompt features plus 34 controls explain a meaningful share of why
some developer ChatGPT conversations succeed and others fail.

### 8.2 Baselines

Four classifiers fitted on the same labels under the same 5-fold split:

| Classifier | ROC-AUC |
|---|---|
| Majority class (always predicts success) | 0.500 |
| Random scoring (mean of 20 seeds) | 0.498 |
| Bag-of-words logistic (top 2k unigrams + bigrams on first prompt) | 0.782 |
| Our 11-feature model with controls | 0.799 |

The headline finding is that our 11 hand-engineered features add 1.7
AUC points on top of a 2,000 feature bag-of-words baseline. Bag of words
already captures most of the signal that lives in the wording. The extra
1.7 points are the share that lives in features bag-of-words does not
summarize cleanly: refinement turns, role flag, correction cycles.

### 8.3 Primary regression coefficients

After controlling for language, source type, snapshot, and model variant:

| Feature | OR | 95% CI | p-value |
|---|---|---|---|
| **Output format (binary)** | **1.752** | [1.400, 2.193] | 9.4e-7 |
| Specification clarity (count) | 1.473 | [0.972, 2.233] | 0.068 |
| **Refinement turns** | **1.188** | [1.112, 1.269] | 3.4e-7 |
| Total examples | 1.004 | [0.985, 1.023] | 0.667 |
| Iteration count | 1.004 | [0.997, 1.011] | 0.294 |
| **First prompt tokens** | **0.9995** | [0.9993, 0.9998] | 7.5e-4 |
| **Prompt token growth** | **0.9995** | [0.9992, 0.9997] | 6.3e-5 |
| **First constraint count** | **0.942** | [0.912, 0.974] | 4.3e-4 |
| Specification clarity (binary) | 0.929 | [0.538, 1.602] | 0.790 |
| **Role instruction (binary)** | **0.651** | [0.498, 0.851] | 0.002 |
| Correction cycles | ~0 | (separates classes) | 0.971 |

In plain language:

- **Output format** is the strongest positive lever. Adding "respond in
  JSON" or "return markdown" raises the odds of success by 75%.
- **Refinement** helps. Each refinement turn adds 19% to the odds.
- **Constraints** slightly hurt. Each extra "must / do not" phrase
  lowers the odds by 6%. Discussion of why this might be in Section 9.
- **Bare role prompts** ("you are an expert") hurt by 35% in isolation.
  The interaction analysis (Section 8.7) explains why.
- **Length** and **growth** are small per-token negatives but
  significant. Long and growing prompts correlate with worse outcomes,
  probably because they signal underspecification.
- **Correction cycles** almost perfectly predict failure (the OR goes
  to zero numerically because of perfect separation).

### 8.4 Feature distributions

Mean values of selected features for success vs failure conversations.
Biggest visible separations:

- Correction cycles: 0.0 (success) vs 0.28 (failure)
- Prompt length: 188 tokens (success) vs 210 tokens (failure)
- Refinement turns: 0.54 (success) vs 0.87 (failure)
- Examples: 1.82 (success) vs 1.38 (failure)

### 8.5 Correlation matrix

Spearman correlations among the prompt and behavioral features. Largest
pairwise correlation is between refinement turns and correction cycles,
which still stays below 0.5. Multicollinearity is low and is not driving
the regression coefficients.

### 8.6 Feature group ablation

Drop each feature group from the model and refit. Measure the AUC drop.

| Group dropped | columns | AUC | Δ AUC |
|---|---|---|---|
| Prompt-engineering features | 11 | 0.756 | -0.043 |
| Source type | 5 | 0.782 | -0.016 |
| Repository language | 12 | 0.786 | -0.013 |
| ChatGPT model variant | 8 | 0.794 | -0.005 |
| Snapshot date | 9 | 0.798 | -0.001 |

The eleven prompt features carry about three times the predictive load
of the next-largest group. Snapshot date is essentially free once the
prompt features are in, which means temporal drift in the data is not
driving the headline results.

### 8.7 Pre-registered interactions

We added four two-way interactions to the model in a single refit:

| Interaction | OR | 95% CI | p-value |
|---|---|---|---|
| Output Format × Refinement | 0.894 | [0.83, 0.96] | 0.002 |
| **Role × Output Format** | **5.284** | [3.37, 8.29] | <0.001 |
| Iterations × Prompt Length | 1.000 | [1.00, 1.00] | 0.002 |
| Output Format × Constraints | 0.957 | [0.91, 1.01] | 0.086 |

The Role × Output Format result is the most actionable finding in the
paper. Role on its own is OR 0.65 (negative), but combining role with an
explicit output format produces a joint odds factor of about 6.0
relative to a prompt with neither. Worked example:

- Prompt A: "You are a Python expert. Help me sort a list."
  Role present, format absent. Joint factor on these two terms:
  0.65 × 1.0 × 1.0 = 0.65.
- Prompt B: "You are a Python expert. Sort the list and return only
  valid Python code in a fenced block."
  Role and format both present. Joint factor:
  0.65 × 1.75 × 5.28 ≈ 6.0.
- Prompt B is roughly 9 times better than Prompt A on the role and
  format terms.

The lesson: do not use bare role prompts. Combine role with a concrete
output anchor.

### 8.8 Cross-model generalization (Kimi, Claude, Gemini)

We replayed 200 prompts from DevGPT through three independent LLMs in
two conditions: zero-shot (minimal system prompt) and engineered (system
prompt that asks for explicit constraints, output format, and complexity
analysis). A rubric judge graded each output on a 0-4 scale across four
axes (code present, addresses task, looks correct, follows structure).

| Vendor | Zero | Eng | Δ score | Cohen's d | Δ success rate |
|---|---|---|---|---|---|
| Kimi K2 (Moonshot AI) | 2.51 | 3.12 | +0.61 | 0.70 | +23 pp |
| Claude Sonnet 4.6 (Anthropic) | 3.03 | 3.37 | +0.35 | 0.59 | +14 pp |
| Gemini 3.1 Pro (Google) | 2.48 | 3.17 | +0.69 | 0.80 | +24 pp |

The engineered prompt effect is real on every vendor. The lift is
larger for vendors whose zero-shot baseline starts lower.

Pairwise Cohen's kappa between the three vendors on the binary success
label is 0.39 to 0.43 ("moderate" agreement). Vendors agree on the easy
and hard prompts and split on the boundary cases.

### 8.9 Manual validation of the success label

We sampled 200 random conversations and manually re-labeled the first
50 against the protocol. Results:

- 92.0% raw agreement
- Cohen's kappa = 0.834 ("almost perfect")
- 4 disagreements out of 50

The four disagreements are conversations where code is present but the
answer drifts to a related but different problem from what the user
asked. The auto labeler is conservative on those.

### 8.10 Language subgroups

Per-language ROC-AUC for languages with at least 25 conversations:

| Language | n | success % | AUC |
|---|---|---|---|
| CSS | 1,313 | 73.1 | 0.809 |
| Python | 703 | 53.8 | 0.716 |
| Assembly | 25 | 72.0 | 0.700 |
| C | 136 | 63.2 | 0.668 |
| Go | 110 | 62.7 | 0.668 |
| Jupyter Notebook | 270 | 40.0 | 0.667 |
| JavaScript | 345 | 70.7 | 0.639 |
| Rust | 63 | 73.0 | 0.623 |
| TypeScript | 652 | 69.9 | 0.622 |
| Java | 163 | 68.7 | 0.620 |
| HTML | 329 | 51.4 | 0.602 |
| C++ | 186 | 50.5 | 0.579 |
| Dockerfile | 72 | 47.2 | 0.555 |
| Kotlin | 38 | 78.9 | 0.550 |
| Ruby | 26 | 73.1 | 0.500 |
| C# | 100 | 64.0 | 0.481 |
| Batchfile | 67 | 71.6 | 0.346 |
| Shell | 30 | 70.0 | 0.315 |

Best on CSS, Python, and Assembly. Performs at chance on Shell,
Batchfile, and C# where samples are small and conversation styles vary.

### 8.11 Temporal stability

Per-snapshot fits show the output format effect is positive in every
snapshot with n ≥ 200 (point estimates between 1.33 and 3.62). The
signal is stable across the August 2023 to May 2024 window.

---

## 9. Why some results are surprising

Three findings need explanation.

### Why is the role main effect negative?

A naive reading would be: "you are an expert" prompts are harmful. The
interaction analysis says the opposite. Role on its own correlates with
vague, exploratory questions, which fail more often. Role plus a
concrete output format correlates with developers who know what they
want and have encoded it precisely. The negative role main effect is a
confounder of user intent, not a property of role prompting itself.

### Why is constraint count negative?

Each extra constraint phrase lowers the odds by 6%. Small but
consistent. One reading is that conversations with many constraints tend
to be ones where the developer is fencing off a hard or ambiguous
problem, and those problems are harder to solve regardless of how the
prompt is written.

### Why is refinement positive in the joint model?

Earlier descriptive studies treat refinement as a sign of trouble. Our
model controls for correction cycles separately. Correction cycles are
the bad refinement (the user fixing a wrong answer). Pure refinement is
clarification, follow-up, and scope expansion, which is positive.
Treating refinement as a single variable conflates two opposing effects.

---

## 10. Threats to validity

The full discussion is in Section V of the paper. The short version:

- **Construct validity**: the success label is a textual heuristic, not
  a ground-truth code execution. The kappa = 0.834 audit shows the
  heuristic is reliable but conservative.
- **Internal validity**: the study is observational. We control for the
  available metadata but cannot rule out unobserved confounders
  (developer experience, task difficulty).
- **External validity**: DevGPT contains conversations developers chose
  to share publicly. Selection bias toward funny or dramatic
  conversations is a known issue with the corpus. The data is also
  English-heavy and skews toward web languages.
- **Conclusion validity**: the cross-vendor study uses a rubric judge
  that is itself an LLM. We mitigate by reporting effect sizes alongside
  p-values and using inter-vendor kappa as a sanity check.

---

## 11. Reproducibility

Everything in the paper is reproducible from the project repository.

### Software stack

- Python 3.12
- scikit-learn 1.4 (logistic regression, cross validation, baselines)
- statsmodels 0.14 (confidence intervals, p-values, interaction model)
- pandas 2.2 (data wrangling)
- numpy 1.26 (numerics)
- matplotlib 3.10 (figures)

All versions pinned in `requirements.txt`. Random seed 42 throughout.

### Pipeline scripts

Each analytical step is one Python script and emits a JSON or parquet
artifact. From the project root:

```
python pipeline/load_and_clean_devgpt.py     # raw JSON to parquet
python pipeline/feature_extraction.py         # 11 features per convo
python pipeline/success_label_and_model.py    # primary logistic regression
python pipeline/run_baselines.py              # majority/random/BOW
python pipeline/run_ablation.py               # feature-group ablation
python pipeline/run_temporal_drift.py         # per-snapshot logits
python pipeline/run_interactions.py           # 4 pre-registered terms
python pipeline/run_validation_kappa.py       # manual audit kappa
python pipeline/multi_model_study.py          # cross-vendor replication
python pipeline/sensitivity_robustness.py     # language subgroup AUC
```

Each script reads only the parquet feature matrix and the labels, never
the raw text, so the artifacts can be regenerated without re-fetching
the corpus.

### Number provenance

Every number in the paper resolves to a file under `results/`:

| Claim | Source file |
|---|---|
| 6,413 / 54,449 / 55.03% | `results/model_metrics.json` |
| All 11 odds ratios with CIs and p-values | `results/coefficients.csv` |
| Baselines (0.500 / 0.498 / 0.782 / 0.799) | `results/baselines.json` |
| Ablation Δ AUC | `results/ablation.json` |
| Interactions (Role × Output Format OR 5.28) | `results/interactions.json` |
| Cross-model effects | `results/multi_model/multi_model_study.json` |
| kappa = 0.834 | `results/validation_kappa.json` |
| Per-snapshot OR | `results/temporal_drift.json` |
| Language subgroup AUC | `results/sensitivity/language_subgroup_summary.csv` |

All values were verified end-to-end against these source files before
the paper was finalized.

### Companion website

A live companion at the project URL streams the cross-model study
in-browser: a developer types a coding prompt, three vendors race in
parallel, and a Claude Haiku judge grades each output against the same
rubric used in the offline study. The site reads the same coefficient
and ablation JSON files referenced in this paper.

---

## 12. How to compile this paper from this folder

```
pdflatex main.tex
pdflatex main.tex
```

Two passes resolve cross-references for tables, figures, and citations.

LaTeX packages required: `amsmath`, `amssymb`, `graphicx`, `url`,
`booktabs`, `tikz` (with `shapes`, `arrows.meta`, `positioning`
libraries). All of these come with a standard MiKTeX or TeXLive install.

The compiled PDF is 7 pages and is also included as `main.pdf`.

---

## 13. How to regenerate the figures

```
python make_figures.py
```

The script reads `results/baselines.json`, `results/ablation.json`,
`results/interactions.json`, `results/temporal_drift.json`,
`results/coefficients.csv`, and `results/model_dataset.parquet`, then
writes nine PNG files into `figures/` at 300 dpi. Each figure is sized
to the IEEE column width (3.3 inches) so axes and tick labels stay
legible at print scale.

Figure list:

1. Pipeline diagram (TikZ inside `main.tex`) -- analysis pipeline
2. `fig_baselines.png` -- ROC-AUC comparison across four classifiers
3. `fig_odds_ratio_forest.png` -- forest plot of feature odds ratios
4. `fig_feature_dist.png` -- mean feature values by success vs failure
5. `fig_correlation.png` -- Spearman correlation matrix
6. `fig_ablation.png` -- AUC drop per dropped feature group
7. `fig_interactions.png` -- pre-registered interaction effects
8. `fig_cross_model.png` -- engineered vs zero-shot per vendor
9. `fig_kappa_heatmap.png` -- pairwise vendor agreement
10. `fig_temporal_drift.png` -- per-snapshot odds ratios

---

## 14. Files in this zip

- `main.tex` -- IEEE conference paper LaTeX source. Inline
  `thebibliography` with 15 references, no separate `.bib` file.
- `main.pdf` -- compiled output (7 pages).
- `figures/` -- 9 PNG figures at 300 dpi.
- `make_figures.py` -- regenerates every figure from the result
  artifacts.
- `README.md` -- this file.

---

## 15. Citation

If you use this work, please cite the paper:

> Mandadi, Bentula, and Konduri. "Prompt Pattern Mining in Vibe Coding:
> A Statistical Audit of 6,413 Developer Conversations." Texas A&M
> University-San Antonio, Spring 2026.

And the underlying corpus:

> Xiao, Z., et al. "DevGPT: Studying Developer-ChatGPT Conversations."
> arXiv:2309.03914, 2023.

---

## 16. License

The code is released under the MIT license. The dataset itself (DevGPT)
follows its own license; refer to the original release for terms.
